import UIKit


enum Directions {
    case left(Int)
    case right(String)
    case bottom(Double)
    case top(Float)
}

protocol Person {
    
    var name: String {get set}
    var age: Int {get set}
    
    func getDetails() -> (name: String, age: Int)
    
//    func someGenericFunction<T>( value: T) where T: Sequence
}

protocol Vehicle {
    
}

typealias someCompostion = Person & Vehicle

class MyPerson: someCompostion {
    
//    func someGenericFunction<T>(value: T) where T : Sequence {
//         T.Type
//    }
    
    
    var name: String = {
        return "Praveen"
    }()
    
    var age: Int = {
        return 28
    }()
    
    func getDetails() -> (name: String, age: Int) {
        return (self.name, self.age)
    }
    
}

//rawValue


