import UIKit
import Combine


let publisher = Just("Hello World")

let cancellabel = publisher.sink { value in
    print(value)
}
cancellabel.cancel()

let timer = Timer.publish(every: 1, on: .main, in: .common)
let cancellabl = timer.autoconnect().sink { timeStamp in
    print(timeStamp)
}
