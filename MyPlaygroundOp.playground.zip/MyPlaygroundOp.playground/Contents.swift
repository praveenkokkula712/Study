import UIKit

var greeting = "Hello, playground"

var name: String? = "String"
var name1: String! = "Str"

print(name)
print(name1!)
