import UIKit
import Combine
import Foundation

//var greeting = "Hello, playground"



//let publisher1 = [1,2,3,4,5].publisher
//let publisher2 = [6,7,8,9,10].publisher
//
//
//let combined = publisher1.zip(publisher2)
//let cancellable = combined
//    .compactMap({"publisher 1:\($0.0), publisher2:\($0.1) "})
//    .sink { value in
//        print(value)
//    }

//enum NumberError: Error {
//    case notFound
//}
//
//let numbers = [1,2,3,4,5,3,4,5,6,3,4,5,6].publisher
//
//let anyCancellable = numbers
//    .tryMap { value in
//        if value == 6 {
//            throw NumberError.notFound
//        }
//        return value
//    }
//    .retry(3)
//    
//anyCancellable.sink { result in
//    switch result {
//    case .finished:
//        print("finish")
//    case .failure(let error):
//        print(error)
//    }
//} receiveValue: { value in
//    print(value)
//}

//var position = [0,2,3,4,1,5,6]
//print(position)
//func alterArray(with numbers: [Int]) -> [Int] {
//    for pos in position.reversed().makeIterator() {
//        if numbers.contains(pos) {
//            position.removeAll(where: {$0 == pos})
//            position.insert(pos, at: 0)
//        }
//    }
//    return position
//}
//print(alterArray(with: [0,5,2,3]))

//let subject = PassthroughSubject<Int,Never>()
//
//let cancellable = subject
//    .sink { value in
//        print(value)
//    }
//subject.send(0)
//
//let current = CurrentValueSubject<Int, Never>(1)
//let can = current.sink { value in
//    print(value)
//}
//current.send(9)
/*
class EvenSubject<Failure: Error> : Subject {
    
    
    typealias Output = Int
    
    private var wrapped: PassthroughSubject<Int, Failure>
    
    init(value: Int) {
        wrapped = PassthroughSubject<Int,Failure>()
        let initValue = value % 2 == 0 ? value : (value + 1)
        send(initValue)
        wrapped.send(initValue)
    }
    
    func send(subscription: Subscription) {
        wrapped.send(subscription: subscription)
    }
    
    func send(_ value: Int) {
        if value % 2 == 0 {
            wrapped.send(value)
        } else {
            wrapped.send(value + 1)
        }
    }
    
    func send(completion: Subscribers.Completion<Failure>) {
        wrapped.send(completion: completion)
    }
    
    func receive<S>(subscriber: S) where S : Subscriber, Failure == S.Failure, Int == S.Input {
        wrapped.receive(subscriber: subscriber)
    }
}

let even = EvenSubject<Never>(value: 12)
let cann = even.sink { value in
    print(value)
}

even.send(15)


let urlString = "https://tr-casinononcriticalfeed-api-container.ivycomptech.co.in/api/rest/casino/feeds/v1/getJackpotPoolInfo?brand=BETMGMMI&currency=USD"

public struct JackpotPoolInfo: Codable {
    
    public let statusCode: Int?
    public let status: String?
    public let errorMessage: String?
    public let feedType: String?
    public let jackpotGroupPoolList: [JackpotGroupPoolList]?
    public let hotJackpotGroupList:[String]?
}

public struct JackpotGroupPoolList: Codable {
    public let amount,
               jackpotGroupId,
               jackpotGroupName,
               value,
               jpCurrency,
               highestCompletedPercentage: String?
    public let gamesAvailable: [GamesAvailable]?
    public let subJackpotDetails: [SubJackpotDetails]?
}

public struct GamesAvailable: Codable {
    public let game,sid,name : String?
}

public struct SubJackpotDetails: Codable {
    public let subJackpotValue,
               subJackpotAmount,
               subJackpotName,
               jackpotFeedId,
               triggerType,
               triggerInfo,
               awardType,
               lastWinAmount,
               lastWinTime,
               subJPCompPercent: String?
}

func fetchData() -> AnyPublisher<JackpotPoolInfo, Error> {
    let url = URL(string: urlString)!
    return URLSession.DataTaskPublisher(request: URLRequest(url: url), session: .shared)
        .tryMap({ data, response in
            print("retried %%%%%%%")
            return data
        })
        .decode(type: JackpotPoolInfo.self, decoder: JSONDecoder())
        .receive(on: DispatchQueue.main)
        .eraseToAnyPublisher()
}

let data = fetchData()
    .sink { completion in
        switch completion {
        case .finished:
            print("finished")
        case .failure(let error):
            print(error)
        }
    } receiveValue: { response in
        print(response.statusCode)
    }




let cv = CurrentValueSubject<String, Never>("")
let anycan = cv
    .debounce(for: 0.5, scheduler: DispatchQueue.main)
    .sink { value in
        print(value)
    }
cv.send("p")
cv.send("q")
cv.send("r")
cv.send("s")
cv.send("t")
cv.send("u")
cv.send("v")
cv.send("w")




let subject = PassthroughSubject<String,Never>()
let anyCancellabel:AnyCancellable?

anyCancellabel = subject.debounce(for: .seconds(0.25), scheduler: DispatchQueue.main)
    .sink(receiveValue: { value in
    print("\(value)")
    })

subject.send("1")
subject.send("2")
subject.send("3")
subject.send("4")
subject.send("5")
subject.send("6")
subject.send("7")
subject.send("8")
subject.send("9")
subject.send("10")
subject.send("11")
subject.send("12")
subject.send("13")
subject.send("14")
subject.send("15")
 */


//extension Publisher  where Output == Int {
//    func filterNumbers() -> AnyPublisher<Int,Failure> {
//        self.filter({$0 % 2 == 0})
//            .eraseToAnyPublisher()
//    }
//}
//
//extension Publisher {
//    
//    func filterAndMap<T>(_ isIncluded: @escaping (T) -> Bool, _ transform: @escaping (Output) -> T) -> AnyPublisher<T, Failure> {
//        self
//            .map{transform($0)}
//            .filter{isIncluded($0)}
//            .eraseToAnyPublisher()
//    }
//    
//}
//let numbers = [1,2,3,4,5,6,7,8,9].publisher
//
//let cancellable = numbers
//    .filterNumbers()
//    .sink { value in
////        print(value)
//    }
//
//let _ = numbers
//    .filterAndMap { value in
//        return value % 2 == 0
//    } _: { value in
//        return value * 2
//    }
//    .sink { value in
////        print(value)
//    }
//
//let subject = Just("Hello world")
//    
//let _ = subject
//    .sink { value in
//        print(value)
//    }

//let _ = numbers
//    .map({$0 * 2})
//    .filter({$0 % 2 == 0})
//    .print("Debug:")
//    .sink { value in
//        print(value)
//    }
    
//var anyCancellabel: AnyCancellable?

//let timer = Timer
//    .publish(every: 1.0, on: .main, in: .common)
//    .autoconnect()
//
//anyCancellabel = timer
//    .sink { value in
//        print("recevied")
//    }

//let values:[Double] = [1,2,3,4,5,5,6,1,5,2]
//
//let sub = values.publisher
//    .removeDuplicates(by: {$0 == $1})
//    .sink { value in
//        print(value)
//    }

//let collect = [1,2,3,4,5,6,7, 0,8,9]
//
//struct NoZeroValuesAllowedError: Error {}
//
//let sub = collect.publisher
//    .tryFilter { num in
//        if num <= 0 {
//            throw NoZeroValuesAllowedError()
//        }
//        return num < 10
//    }
//    .ignoreOutput()
//    .sink { completion in
//        switch completion {
//        case .finished:
//            print("finished")
//        case .failure(let error):
//            print(error.localizedDescription)
//        }
//    } receiveValue: { value in
//        print(value)
//    }

//let collect = (1...10).publisher
//let sub = collect
//    .compactMap({$0})
//    .filter({$0 > 5})
////    .collect()
//    .max()
//    .sink { value in
//        print(value)
//    }


//let collect = ["1", "abcde","2", "3", "abc", "abcd"]
//let collect2 = ["10", "ab","20", "30", "abcooo", "abcdoooo"]
//
//let sub = collect.publisher
//    .append(collect2.publisher)
//    .collect()
//    .sink { value in
//        print(value)
//    }

//let url = "https://dummy.restapiexample.com/api/v1/employees"
//let urlRequest = try? URLSession.shared.dataTaskPublisher(for: URL(string: url)!)
//    .print("debug")
//    .map({$0.data})
//    .compactMap({String(data: $0, encoding: .utf8)})
//    .sink(receiveCompletion: { _ in
//        
//    }, receiveValue: { value in
//        print(value)
//    })

//let a = [1,2,3,4]
//let b = ["a","b","c"]
//
//
//let sub = a.publisher
//    .zip(b.publisher)
//    .count()
//    .sink { value in
//        print(value)
//    }

//let subjec = PassthroughSubject<String, Never>()
//
//let cancellabel = subjec
//    .setFailureType(to: URLError.self)
//    .map({ URLSession.shared.dataTaskPublisher(for: URL(string: "https://google&index=\($0)")!) })
//    .switchToLatest()
//    .replaceError(with: (Data(), URLResponse()))
//    .sink { value in
//        print(value)
//    }
//
//subjec.send("1")
//subjec.send("2")
//subjec.send("3")
//subjec.send("4")
//subjec.send("5")
//subjec.send("6")
//subjec.send("7")


//let pub = [1,2,3,4,5,6].publisher
//    .map({($0,Int.random(in: 0...100))})
//    .print("random")
//    .multicast(subject: PassthroughSubject<(Int, Int), Never>())
//
//let can1 = pub.sink { value in
//    print("first \(value)")
//}
//
//let can2 = pub.sink { value in
//    print("Second : \(value)")
//}
//pub.connect()


//class MyObject: ObservableObject {
//    @Published var int:Int = 0
//}
//
//let sub = [1,2,3,4].publisher
//    .assign(to: &MyObject().$int)

struct ZeroError: Error {
    
}
//
//let pub = [1,2,3,4,5,6,0,7,8,9].publisher
//    .tryFilter({ value in
//        if value == 0 {
//            throw ZeroError()
//        }
//        return value % 2 == 0
//    })
//    .catch { value in
//        return Just(0)
//    }
//    .sink { value in
//        print(value)
//    }

//let sub = PassthroughSubject<Int, Never>()
//
//let cancell = sub
//    .tryFilter { value in
//        if value == 0 {
//            throw ZeroError()
//        }
//        return value.isMultiple(of: 5)
//    }
//    .breakpointOnError()
//    .sink { completion in
//        switch completion {
//        case .finished:
//            print("finished")
//        case .failure(let error):
//            print(error.localizedDescription)
//        }
//    } receiveValue: { value in
//        print(value)
//    }
//
//sub.send(20)
//sub.send(30)
//cancell.cancel()
//sub.send(40)
//sub.send(50)
//sub.send(60)
//sub.send(70)

//func generateNumber() -> Future<Int,Never> {
//    return Future() { promise in
//        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
//            promise(.success(Int.random(in: 0...10)))
//        }
//    }
//}
//
//let cancel = await generateNumber().value
//print(cancel)

//let cancell = generateNumber()
//    .sink { value in
//        print(value)
//    }


//func generateANumber() -> AnyPublisher<Int,Error> {
//    Deferred {
//        Future() { promise in
//            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
//                let randomNumber = Int.random(in: 0...10)
//                if randomNumber == 0 {
//                    promise(.failure(ZeroError()))
//                } else {
//                    promise(.success(randomNumber))
//                }
//            }
//        }
//    }
//    .eraseToAnyPublisher()
//}
////
//
//let number =   generateANumber()
//    .sink { completion in
//        switch completion {
//        case .failure(let error):
//            print(error.localizedDescription)
//        case .finished:
//            print("finished")
//        }
//    } receiveValue: { value in
//        print(value)
//    }
//
//let number1 =   generateANumber()
//    .sink { completion in
//        switch completion {
//        case .failure(let error):
//            print(error.localizedDescription)
//        case .finished:
//            print("finished1")
//        }
//    } receiveValue: { value in
//        print("second value: \(value)")
//    }


//let just = Just("Number").eraseToAnyPublisher()
//just.sink { value in
//    print(value)
//}

//func generateNumber() -> AnyPublisher<Int,Error> {
//    Deferred {
//        Future() { promise in
//            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
//                let random = Int.random(in: 0...10)
//                promise(.success(random))
//            }
//        }
//    }.eraseToAnyPublisher()
//}
////
////
//
//let number = generateNumber()
//
//
//let number1 = number.sink { value in
//    print("completion1")
//} receiveValue: { value in
//    print(value)
//}
//
//let number2 = number.sink { value in
//    print("completion2")
//} receiveValue: { value in
//    print(value)
//}
//let number3 = number.sink { value in
//    print("completion3")
//} receiveValue: { value in
//    print(value)
//}


//let url = URL(string:"https://tr-casinononcriticalfeed-api-container.ivycomptech.co.in/api/rest/casino/feeds/v1/getJackpotPoolInfo?brand=BETMGMMI&currency=USD")!
//
//let sub = URLSession.shared.dataTaskPublisher(for: url)
//    .map(\.data)
//    .catch() { _ in
//        Just(Data())
//    }
//    .share()
//    .makeConnectable()
//
//let cancel1 = sub
//    .sink { completion in
//        print("finised")
//    } receiveValue: { value in
//        print(String(data: value, encoding: .utf8))
//    }
//
//DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
//    let cancel2 = sub
//        .sink { completion in
//            print("finised2")
//        } receiveValue: { value in
//            print(String(data: value, encoding: .utf8))
//        }
//}
//
//DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
//    let _ = sub.connect()
//}

//let array = (0...100).publisher
//    .dropFirst(20)
//    .sink { value in
//        print(value)
//    }

//let timer = Timer.publish(every: 1, on: .main, in: .common)
//    .autoconnect()
//
//final class MySubscriber: Subscriber {
//    
//    typealias Input = Date
//    
//    typealias Failure = Never
//    
//    func receive(subscription: any Subscription) {
//        print("received subscription")
//        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
//            subscription.request(.max(3))
//        }
//    }
//    
//    func receive(_ input: Date) -> Subscribers.Demand {
//        print("value \(input)")
//        return .none
//    }
//    
//    func receive(completion: Subscribers.Completion<Never>) {
//        print("finished")
//    }
//}
//
//let sub = AnySubscriber(MySubscriber())
//timer.subscribe(sub)

//let pub = (0...1000000).publisher
//let sub = pub
//    .throttle(for: .seconds(0.1), scheduler: RunLoop.main, latest: true)
//    .sink { value in
//        print(value)
//    }

//let subscription = AnySubscriber<Int,Never> { sub in
//    return sub.request(.max(1000))
//} receiveValue: { number in
//    print(number)
//    return .none
//} receiveCompletion: { completion in
//    switch completion {
//    case .finished:
//        print("finished")
//    case .failure(let error):
//        print(error.localizedDescription)
//    }
//}

//let backGroundQueue = DispatchQueue(label: "myQueue", attributes: .concurrent)
//
//let collection = (0...10)
//    .dropLast(8)
//    .publisher
//    .subscribe(on: backGroundQueue)
//    .receive(on: RunLoop.main)
//    .sink { value in
//        print(value)
//    }
//
//

//let timer = Timer.publish(every: 1, on: .main, in: .default)
//    .autoconnect()
//    .sink { value in
//        print(value)
//    }
//
//DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
//    timer.cancel()
//}

//class UserInfo: ObservableObject {
//    @Published var int: Int
//    
//    init(int: Int) {
//        self.int = int
//    }
//    
//    func increase() -> Int {
//        self.int += 1
//        return self.int
//    }
//}
//
//let userInfo = UserInfo(int: 24)
//
//let cancel = userInfo
//    .objectWillChange
//    .sink { _ in
//        print("value increased")
//        print(userInfo.int)
//    }
//
//print(userInfo.increase())
// pwwkewrstuv
//func getUnique(value: String) -> (String, Int) {
//    var set = Set<Character>()
//    var small = [Character]()
//    var long = [Character]()
//    for a in value {
//        if set.insert(a).inserted {
//            small.append(a)
//        } else {
//            if small.count > long.count {
//                long = small
//            }
//            small.removeAll()
//            small.append(a)
//            set.removeAll()
//            set.insert(a)
//        }
//    }
//    if small.count > long.count {
//        small = long
//    }
//    print(String(long))
//    return (String(long),long.count)
//}
//getUnique(value: "aabcaaaaaaaaaaa")

//struct CustomPublisher: Publisher {
//    let limit: Int
//    func receive<S>(subscriber: S) where S : Subscriber, Never == S.Failure, Int == S.Input {
//        let custom = CustomPublisher(subscriber:subscriber, limit: limit)
//
//    }
//    
//    typealias Output = Int
//    
//    typealias Failure = Never
//    
//    
//}

//let cancel = (0...10)
//    .publisher
//    .map({$0 * 2})
//    .sink { value in
//        print(value)
//    }
//
//print("Map done")
//
//let cancel1 = (0...10)
//    .publisher
//    .flatMap({
//        Just($0).eraseToAnyPublisher()
//    })
//    .sink { value in
//        print(value)
//    }

//let subject = PassthroughSubject<Int,Never>()
//let cancel = subject
//    .throttle(for: .seconds(0.1), scheduler: RunLoop.main, latest: true)
////    .debounce(for: .seconds(0.1), scheduler: RunLoop.main)
//    .sink { value in
//        print(value)
//    }
//subject.send(1)
//subject.send(2)
//subject.send(3)
//subject.send(4)
//subject.send(5)
//subject.send(6)
//subject.send(7)
//subject.send(8)
//subject.send(9)
//subject.send(10)
//subject.send(20)
//subject.send(30)
//subject.send(40)
//subject.send(50)
//subject.send(60)
//subject.send(70)
//subject.send(80)
//subject.send(90)
//subject.send(100)

//let queue = DispatchQueue(label: "com.label.test")
//
//queue.async {
//    let array = (0...10)
//        .publisher
//        .sink { value in
//            print("value from first: \(value)")
//        }
//}
//
//print("outside the block")
//queue.sync {
//    let array = (0...10)
//        .publisher
//        .sink { value in
//            print("value from second: \(value)")
//        }
//}
//print("outside the seconds block")


//let queue = DispatchQueue(label: "com.label.test", attributes: .concurrent)
//
//queue.sync {
//    let array = (0...10)
//        .publisher
//        .sink { value in
//            print("value from first: \(value)")
//        }
//}
//
//print("outside the block")
//queue.sync {
//    let array = (0...10)
//        .publisher
//        .sink { value in
//            print("value from second: \(value)")
//        }
//}
//print("outside the seconds block")

//let group = DispatchGroup()
//
//let queue = DispatchQueue.global()
//
//group.enter()
//queue.async {
//    print("task 1 started")
//    sleep(2)
//    print("task 1 finished")
//    group.leave()
//}
//
//group.enter()
//queue.async {
//    print("task 2 started")
//    sleep(2)
//    print("task 2 finished")
//    group.leave()
//}
//
//group.notify(queue: .main) {
//    print("All are done.")
//}

//let queue = DispatchQueue(label: "com.test.check", attributes: .concurrent)
//var shared = 0
//
//queue.async {
//    print("read 1 \(shared)")
//}
//
//queue.async {
//    print("read 2 \(shared)")
//}
//
//queue.async(flags: .barrier) {
//    shared = 5
//    print("write shared: \(shared)")
//}
//
//queue.async {
//    print("read 3: \(shared)")
//}

//func longTask() async {
//    
//    for i in 1...5 {
//        try? await Task.sleep(nanoseconds: 1000000000)
//        print("task start : \(i)")
//        await Task.yield()
//    }
//    
//    print("Task done")
//}
//
//Task {
//    await longTask()
//}

//func fetchOperation() async {
//    await withTaskGroup(of: String.self) { group in
//        group.addTask {
//            return await fetchData1()
//        }
//        group.addTask {
//            return await fetchData2()
//        }
//        group.addTask {
//            return await fetchData3()
//        }
//        
//        for await result in group {
//            print("recieved :\(result)")
//        }
//        print("all are done.")
//    }
//}
//
//func fetchData1() async -> String {
//    try? await Task.sleep(nanoseconds: 1_000_000_000) // Simulate delay (1 second)
//    return "Data from source 1"
//}
//
//func fetchData2() async -> String {
//    try? await Task.sleep(nanoseconds: 1_000_000_000) // Simulate delay (1 second)
//    return "Data from source 2"
//}
//
//func fetchData3() async -> String {
//    try? await Task.sleep(nanoseconds: 1_000_000_000) // Simulate delay (1 second)
//    return "Data from source 3"
//}
//
//// Usage
//Task {
//    await fetchOperation()
//}


//let eventStream = AsyncStream<Int> { continuation in
//    
//    Task {
//        for i in 1...10 {
//            continuation.yield(i)
//            try await Task.sleep(nanoseconds: 100000000)
//        }
//        continuation.finish()
//    }
//    
//}
//

//struct AsyncNumberSequence: AsyncSequence {
//    
//    typealias Element = Int
//    
//    struct AsynNumberIterator: AsyncIteratorProtocol {
//        var current = 0
//        
//        mutating func next() async throws -> Int? {
//            try await Task.sleep(nanoseconds: 10000000)
//            if current < 5 {
//                current += 1
//                return current
//            }
//            return nil
//        }
//    }
//    
//    func makeAsyncIterator() -> AsynNumberIterator {
//        AsynNumberIterator()
//    }
//}
//
//Task {
//    let numbers = AsyncNumberSequence()
//    
//    for try await result in numbers {
//        print("recived numbers: \(result)")
//    }
//    
//    print("finished valuees.")
//    
//}

//actor Counter {
//    private var count = 0
//    
//    func increment() {
//        count += 1
//    }
//    
//    func getValue() -> Int {
//        return count
//    }
//}
//
//let counter = Counter()
//
//Task {
//    await counter.increment()
//}
//
//Task {
//    let getValue = await counter.getValue()
//    print(getValue)
//}
  
//@TaskLocal
//var requestId: String?
//
//func performTask() async {
//    if let requestId = $requestId.wrappedValue {
//        print("id is:\(requestId)")
//    } else {
//        print("no id")
//    }
//}
//let task = Task {
//    await performTask()
//    
//    await $requestId.withValue("new") {
//         await performTask()
//        
//        await Task {
//            await performTask()
//        }.value
//        
//        await $requestId.withValue("Old") {
//            await performTask()
//        }
//    }
//    await performTask()
//}
//task.cancel()

//@globalActor
//actor Logger: GlobalActor {
//    static let shared  = Logger()
//}
//
//@Logger
//class LoggerManager {
//    var count = 0
//    func add(number: Int) {
//        count += number
//    }
//    
//    func remove(number: Int) {
//        count -= number
//    }
//    
//    func getNumber() -> Int {
//        return count
//    }
//}
//
//Task {
//    let manager = await LoggerManager()
//    await manager.add(number: 8)
//    await manager.remove(number: 5)
//    let number = await manager.getNumber()
//    print(number)
//}

//class MYOperation: Operation {
//    private var taskName: String?
//    
//    init(taskName: String? = nil) {
//        self.taskName = taskName
//    }
//    
//    override func main() {
//        if isCancelled {
//            return
//        }
//        print("starting")
//        Thread.sleep(forTimeInterval: 2)
//        if isCancelled {
//            print("cancelled")
//            return
//        }
//        print("finished")
//    }
//}
//
//let operation = MYOperation(taskName: "Hello")
//let operation1 = MYOperation(taskName: "Hello")
//let operation2 = MYOperation(taskName: "Hello")
//let operation3 = MYOperation(taskName: "Hello")
//let operation4 = MYOperation(taskName: "Hello")
//
//let operationQueue = OperationQueue()
//operation4.addDependency(operation3)
//operation3.addDependency(operation2)
//operation2.addDependency(operation1)
//operation1.addDependency(operation)
//operation.cancel()
//operation2.cancel()
//operationQueue.addOperation(operation)
//operationQueue.addOperation(operation1)
//operationQueue.addOperation(operation2)
//operationQueue.addOperation(operation3)
//operationQueue.addOperation(operation4)

//var name: String? = "String"
//var name1: String! = "Str"
//
//print(name)
//print(name1)

//protocol Myprotocol {
//    associatedtype Model
//    func getReponse(from path: String) async throws -> Model
//}
//
//struct MovieModel: Codable {
//    
//}
//
//class MovieViewModel: Myprotocol {
//    
//    func getReponse(from path: String) async throws -> MovieModel {
//        return MovieModel()
//    }
//    
//    typealias Model = MovieModel
//}

//enum MyEnum<T,R> {
//    case value(T)
//    case anotherValue(T, R)
//}
//
//let myEnum = MyEnum.anotherValue("hello", "World")
//switch myEnum {
//case .value(let string):
//    print(string)
//case .anotherValue(let string, let string2):
//    print(string)
//    print(string2)
//}
//
//let anotherEnum = MyEnum.anotherValue(10, 10)
//switch anotherEnum {
//case .value(let t):
//    <#code#>
//case .anotherValue(let t, let r):
//    <#code#>
//}


//class MyClass {
//    var name: String?
//    var age: Int?
//    
//    init(name: String? = nil, age: Int? = nil) {
//        self.name = name
//        self.age = age
//    }
//}
//
//let myClass = MyClass(name: "Praveen", age: 30)
//let object = Mirror(reflecting: myClass)
//
//for (label, value) in object.children {
//    print("\(label): \(value)")
//}
//enum MyError: Error {
//    case greaterError
//}
//func myAsyncMethod(number: Int) async throws -> Int {
//    Thread.sleep(forTimeInterval: 2)
//    print("recived")
//    if number > 10 {
//        throw MyError.greaterError
//    }
//    return number
//}
//
//async {
//    try await myAsyncMethod(number: 12)
//}

//let subject = CurrentValueSubject<String,Never>("Praveen")
//subject.send("Kokkula")
//
//let anyCancellabel = subject.sink { value in
//    print("value :\(value)")
//}
//
//subject.send("6")

//var myName: String! = "Praveen"
//
//switch myName {
//case .some(let value) :
//    print(value)
//case .none:
//    print("no values")
//}

//@MainActor
//func getValues() -> [String] {
//    return [""]
//}
//
//@MainActor
//class MyClass {
//    
//}
//
//final actor MyActor: Actor {
//    
//}

//func getBearerToken() async throws -> String {
//    return ""
//}
//
//var tokenTask :Task<String, Error>?
//
//func getToken() async throws -> String {
//
//    if tokenTask == nil {
//        tokenTask = Task {
//            return try await getBearerToken()
//        }
//    }
//    
//    defer {
//        tokenTask = nil
//    }
//    return try await tokenTask?.value ?? ""
//}

//enum CopierError: Error {
//    case outOfpages
//}
//
//struct CopyPager {
//    
//    var pagesRemaining: Int
//    
//    mutating func copy(count: Int) throws(CopierError) {
//        guard count < pagesRemaining else {
//            throw .outOfpages
//        }
//        pagesRemaining -= count
//    }
//}
//
//var pager = CopyPager(pagesRemaining: 10)
//
//do {
//    try pager.copy(count: 12)
//} catch CopierError.outOfpages {
//    print("out pages")
//}

//class MyClass {
//    static var myvar: String  {
//        print("static")
////        Thread.sleep(forTimeInterval: 1)
//        return "Praveen"
//    }
//    
//    lazy var myNewVar: String = {
//        print("started")
//        Thread.sleep(forTimeInterval: 2)
//        return "Praveen"
//    }()
//}
//print(MyClass.myvar)
//print(MyClass.myvar)
//print(MyClass.myvar)
//print(MyClass.myvar)
//print(MyClass.myvar)
//let obj = MyClass()
//print(obj.myNewVar)
//print(obj.myNewVar)
//print(obj.myNewVar)
//print(obj.myNewVar)
//print(obj.myNewVar)


//let sub = PassthroughSubject<String, Never>()


//var completions:[() -> Void] = []
//
//func performOperation(action: @escaping () -> Void) {
//    print("inside method")
//    action()
//    completions.append(action)
//    print("done")
//}
//
//performOperation {
//    print("start")
//}
//
//func sort(a :  [Int]) -> Int {
//    let nums = a.filter({$0 > 0}).sorted()
//    var result = 1
//    for num in nums {
//        if result == num {
//            result += 1
//        }
//    }
//    return result
//}
//
//let result = sort(a: [-1,7,-3,-4,-5,6,5,4,3,2,1])
//print(result)

// opaque types

//protocol Shape {
//    func draw() -> String
//}
//
//struct Triangle: Shape {
//    var size: Int
//    func draw() -> String {
//        var result:[String] = []
//        
//        for i in 1...size {
//            result.append(String(repeating: "*", count: i))
//        }
//        return result.joined(separator: "\n")
//    }
//}
//
//struct Flipped: Shape {
//    var size: Int
//    func draw() -> String {
//        let triangle = Triangle(size: size)
//        var result = triangle.draw()
//        var finalResul: [String] = []
//        let components = result.components(separatedBy: "\n")
//        for component in components.reversed() {
//            finalResul.append(component)
//        }
//        return finalResul.joined(separator: "\n")
//    }
//}
//
//
//let triangle = Triangle(size: 3)
////print(triangle.draw())
//
//let flipped = Flipped(size: 3)
////print(flipped.draw())
//
//struct Square<T: Shape>: Shape {
//    var shape: T
//    
//    func draw() -> String {
//        shape.draw().replacingOccurrences(of: "\n", with: "\t")
//    }
//    
//    func getShape() -> T {
//        return shape
//    }
//}
//
//let square = Square(shape: triangle)
//
//print(square.getShape().draw())
//print(square.draw())

//class Person {
//    private var name: String
//    weak var apartment: Apartment?
//    init(name: String) {
//        self.name = name
//        print("initialised with : \(name)")
//    }
//    deinit {
//        print("deinited with : \(name)")
//    }
//}
//
//class Apartment {
//    private var floors: Int
//    weak var tenant: Person?
//    init(floors: Int) {
//        self.floors = floors
//        print("Apartment init with:\(floors)" )
//    }
//    
//    deinit {
//        print("Apartment deinit")
//    }
//}
//
//
//
//var person1: Person?
////var person2: Person?
////var person3: Person?
//var apartment: Apartment?
//
//person1 = Person(name: "praveen")
////
////
////person2 = nil
////person1 = nil
////person3 = nil
//apartment = Apartment(floors: 3)
//person1?.apartment = apartment
//apartment?.tenant = person1
//
//print("\(person1?.apartment)")
//print("\(apartment?.tenant)")
//
//person1 = nil
//apartment = nil


// protocol composition
// associated values , associated types
















