import UIKit

var greeting = "Hello, playground"
print(greeting)


class Employee {
    var id: Int
    var name: String
    var mackBook: MacBook?
    init(id: Int, name: String, macBook: MacBook? = nil) {
        self.id = id
        self.name = name
        self.mackBook = macBook
    }
    
    deinit {
        print("Employee is removed: \(self.name)")
    }
}

class MacBook {
    weak var assignee: Employee?
    var version: Int
    
    init(assignee: Employee?, version: Int) {
        self.assignee = assignee
        self.version = version
    }
    
    deinit {
        print("Macbook object is removed for employee: \(self.assignee?.name)")
    }
}

//strong, weak , unowned


var sindhuja: Employee? = Employee(id: 100, name: "Sindhuja")
var macBook: MacBook? = MacBook(assignee:sindhuja!, version: 10)

sindhuja?.mackBook = macBook


macBook = nil
sindhuja = nil
