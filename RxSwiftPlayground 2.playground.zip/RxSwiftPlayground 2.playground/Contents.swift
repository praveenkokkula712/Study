import UIKit
import Dispatch


let icons = [-1,2,-3,4,nil]

Set(icons)




















let privateQueue = DispatchQueue(label: "com.label.private")
let main = DispatchQueue.main
let high = DispatchQueue.global(qos: .userInteractive)
let low = DispatchQueue.global(qos: .background)
let privateConcurrent = DispatchQueue(label: "com.label.serial", qos: .background, attributes: .concurrent)

let workItem = DispatchWorkItem {
    print("Hello text")
}
print("performing workItem")
workItem.perform()
workItem.cancel()
let globalQueue = DispatchQueue.global()
globalQueue.async(execute: workItem)
print("performing global queue")


class Solution {
    func isThree(_ n: Int) -> Bool {
        var count = 0
        var result = false
        for i in 1...n {
            if n % i == 0 {
                print(i)
                count += 1
            }
            if count > 3 {
                result = false
                break
            }
            if count == 3 {
                result = true
            }
        }
        return result
    }
    
    func isPrefixString(_ s: String, _ words: [String]) -> Bool {
        var str = ""
        for i in words {
            str += i
            if str == s {
                return true
            }
        }
        return false
    }
    
    func findDifference(_ nums1: [Int], _ nums2: [Int]) -> [[Int]] {
        let set1 = Set(nums1)
        let set2 = Set(nums2)
        let first = Array(set1.filter({ number in
            !set2.contains(number)
        }))
        
        let second = Array(set2.filter({ number in
            !set1.contains(number)
        }))
    
        return [first,second]
    }
    
    func convertTime(_ current: String, _ correct: String) -> Int {
        if current == correct {
            return 0
        }
        let currentComponents = current.components(separatedBy: ":")
        let correctComponents = correct.components(separatedBy: ":")
        
        let currentHours = Int(currentComponents.first ?? "0") ?? 0
        let correctHours = Int(correctComponents.first ?? "0") ?? 0
        
        let currentMinutes = Int(currentComponents.last ?? "0") ?? 0
        let correctMinutes = Int(correctComponents.last ?? "0") ?? 0
        
        let hoursDifference = correctHours - currentHours
        let minutesDifference = correctMinutes - currentMinutes
        
        if minutesDifference < 0 {
            let absolute = abs(minutesDifference)
            let _15dif = absolute / 15
            return hoursDifference - 1
        } else {
            return hoursDifference + 1
        }
    }
    
    func findClosestNumber(_ nums: [Int]) -> Int {
        var resultArray = [Int]()
        for i in 0..<nums.count {
            if nums[i] <= 0 {
                resultArray.append(i)
            } else {
                resultArray.append(i)
            }
        }
        return resultArray.min() ?? 0
    }
}


print(Solution().isThree(4))
let s = "a"
let words = ["aa","aa","aaaa","aaaaaa"]
print(Solution().isPrefixString(s, words))
let nums1 = [1,2,3,3]
let nums2 = [1,1,2,2]
print(Solution().findDifference(nums1, nums2))
let current = "00:00"
let correct = "23:59"
print(Solution().convertTime(current, correct))
let nums = [-4,-2,1,4,8]
print(Solution().findClosestNumber(nums))
