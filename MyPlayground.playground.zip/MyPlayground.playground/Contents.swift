import UIKit

var greeting = "Hello, playground"

func categorizeNumbers(_ numbers: [Int]) -> [[String: Int]] {
    var result: [[String: Int]] = []
    
    let categories = ["higher", "lower", "mid"]
    
    for (index, value) in numbers.prefix(categories.count).enumerated() {
        result.append([categories[index]: value])
    }
    
    return result
}

print(categorizeNumbers([67, 34, 89, 22]))
