import UIKit
import Foundation

var greeting = "Hello, playground"

// Merchant, User


// Merchant, QR code generate --> amount as input


// User, scans QR code --> payment initiate

// Payment gateway --> payment process --> Acknowldgement will forwarded to User and Merchant both

enum PaymentStatus {
    case inProgress
    case completed
    case failed
}

struct TransactionDetails {
    var userid: UUID
    var amount: String
    
    init(userid: UUID, amount: String) {
        self.userid = userid
        self.amount = amount
    }
}

protocol MerchantProtocol {
    func generateQr(with data: String) -> String
    
    func getTransactons(with type: PaymentStatus) -> [TransactionDetails]
}






