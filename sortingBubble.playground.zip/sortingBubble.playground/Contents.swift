import UIKit

var greeting = "Hello, playground"


//func bubble(_ array: inout [Int]) {
//    let n = array.count
//    var isSwapped = false
//    
//    for i in 0..<n {
//        for j in 0..<n-i-1 {
//            if array[j] > array[j+1] {
//                array.swapAt(j, j+1)
//                isSwapped = true
//            }
//        }
//        if !isSwapped {
//            break
//        }
//    }
//}
//var numbers = [5, 3, 8, 4, 2]
//bubble(&numbers)
//print(numbers)

//func selectionSort(_ array: inout [Int]) {
//    let n = array.count
//    
//    for i in 0..<n {
//        for j in i+1..<n {
//            if array[i] > array[j] {
//                array.swapAt(i, j)
//            }
//        }
//    }
//}
//
//var numbers = [5, 3, 8, 4, 2]
//selectionSort(&numbers)
//print(numbers)

protocol NotificationFactory {
    func send()
}

class PushNotification: NotificationFactory {
    func send() {
        print("Push notification")
    }
}

class EmailNotification: NotificationFactory {
    func send() {
        print("Push notification")
    }
}

class CombineNotification: NotificationFactory {
    func send() {
        print("Push notification")
    }
}

class NotificationCenterFactor {
    
    enum NotificationType {
        case push, email, combine
    }
    
    func createNotificationFactory(type: NotificationType) -> NotificationFactory {
        switch type {
        case .push:
            return PushNotification()
        case .email:
            return EmailNotification()
        case .combine:
            return CombineNotification()
        }
    }
}

let factory = NotificationCenterFactor()
    .createNotificationFactory(type: .email)

factory
    .send()

print("Hello world")

