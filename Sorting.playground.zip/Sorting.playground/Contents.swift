import UIKit
import Foundation
import SwiftUI

var greeting = "Hello, playground"

/*
var numbers = [5, 3, 8, 4, 2]
func bubbleSort( array: inout [Int]) {
    var n = array.count
    for i in 0...n {
        var isSwapped = false
        for j in 0..<n-i-1 {
            print(array)
            if array[j] > array[j+1] {
                array.swapAt(j+1, j)
                isSwapped = true
            }
        }
        if !isSwapped {
            break
        }
    }
}
print(bubbleSort(array: &numbers))
print(numbers)

var sort = [29, 10, 14, 37, 14]
func selectionSort(with array: inout [Int]) {
    var n = array.count
    for i in 0..<n {
        for j in i+1..<n {
            if array[i] > array[j] {
                array.swapAt(i, j)
            }
        }
    }
}
selectionSort(with: &sort)
print(sort)





func getLongestSubsequence(from array:[Int]) -> [Int] {
    
    guard !array.isEmpty else { return []}
    
    var longestSequence = [Int]()
    let numSet = Set(array)
    
    for num in numSet {
        if !numSet.contains(num - 1) {
            var currentNum = num
            var currentSequence = [Int]()
            
            while numSet.contains(currentNum) {
                currentSequence.append(currentNum)
                currentNum += 1
            }
            
            if currentSequence.count > longestSequence.count {
                longestSequence = currentSequence
            }
        }
    }
    return longestSequence
}
 



struct MyStruct {
    var name: String
    var age: Int
    private var lastName: String
    
    
    private func create() {
        let object = MyStruct(name: "Praveen", age: 20, lastName: "Kokkula")
    }
}


func findThreeSum(in array: [Int]) -> [[Int]] {
    var result = [[Int]]()
    let sorted = array.sorted()
    
    for i in 0..<sorted.count {
        if i > 0 && sorted[i] == sorted[i - 1] {
            continue
        }
        
        var left = i + 1
        var right = sorted.count - 1
        
        while left < right {
            let sum = sorted[i] + sorted[left] + sorted[right]
            if sum == 0 {
                result.append([sorted[i], sorted[left], sorted[right]])
                while left < right && sorted[left] == sorted[left + 1] {
                    left += 1
                }
                while left < right && sorted[right] == sorted[right - 1] {
                    right -= 1
                }
                
                left += 1
                right -= 1
                
            } else if sum < 0 {
                left += 1
            } else {
                right -= 1
            }
        }
    }
    return result
}

func findSum(in array: [Int]) -> [[Int]] {
    let unique = Set(array)
    var result = [[Int]]()
        
    for i in 0..<array.count {
        for j in 0..<array.count {
            var sum = array[i] + array[j]
            sum.negate()
            if unique.contains(sum) {
                result.append([array[i] ,array[j], sum])
            }
        }
    }
    return result
}
let nums = [-1, 0, 1, 2, -1, -4]
let result = findSum(in: nums)
print(result)


func findSlice(in array:[Int], with preSum: Int) -> [Int] {
    var result = [Int]()
    
    var dict = [Int: Int]()
    var new = [Int]()
    var first = new.drop
    
    
    
    
    
    for i in 0..<array.count {
        var isSumFound = false
        var sum: Int = 0
        var index = i+1
        var count = i
        while !isSumFound {
            sum += array[count]
            print(sum)
            if sum == preSum {
                result.append(index)
                result.append(count + 1)
                isSumFound = true
                return result
            }
            if sum > preSum {
                isSumFound = true
            }
            if count >= array.count - 1 {
                isSumFound = true
            }
            count += 1
        }
    }
    if result.isEmpty {
        if let index = array.firstIndex(of: preSum) {
            result.append(index + 1)
            result.append(index + 1)
        } else {
            return [-1]
        }
    }
    return result
}

let result = findSlice(in: [5,3,4], with: 2)
print(result)


func decodeMessage(_ key: String, _ message: String) -> String {
    var dict = [Character: Character]()
    var number = 97
    for char in key {
        let scalar = UnicodeScalar(number)
        let string = String(scalar!).first!
        if dict[char] == nil, char != " " {
            dict[char] = string
            number += 1
        }
    }
    var result = ""
    for char in message {
        if let value = dict[char] {
            result += String(value)
        } else {
            result += String(char)
        }
    }
    return result
}
let result = decodeMessage("the quick brown fox jumps over the lazy dog", "vkbs bs t suepuv")
print(result)

func numberOfPairs(_ nums: [Int]) -> [Int] {
    var result = 0
    var n = nums
    func removeDup(in n: inout [Int]) -> Bool {
        for i in 0..<n.count {
            for j in i+1..<n.count {
                if n[i] == n[j] {
                    n.remove(at: j)
                    n.remove(at: i)
                    return true
                }
            }
        }
        return false
    }
    
    var isFound = true
    while isFound {
        isFound = removeDup(in: &n)
        if isFound {
            result += 1
        }
    }
    return [result, n.count]
}

let result = numberOfPairs([1,1])
print(result)

func minimumOperations(_ nums: [Int]) -> Int {
        var n = nums
        var result = 0
        var isFound = true
        while isFound {
            n.removeAll(where: {$0 == 0})
            var min = n.min()!
            for i in 0..<n.count {
                if n[i] != 0 {
                    n[i] = n[i] - min
                }
            }
            result += 1
            isFound = n.filter {$0 != 0}.count > 0
        }
        return result
    }

let result = minimumOperations([1,5,0,3,5])
print(result)

func fetchResponse(from url: String) async throws -> Any? {
    guard let url = URL(string: url) else {
        return nil
    }
    do {
        let (data, response) = try await URLSession.shared.data(from: url)
        if let response = response as? HTTPURLResponse, response.statusCode != 200 {
            return nil
        }
        let parsedData = try JSONDecoder().decode([String: String].self, from: data)
        return parsedData
    } catch {
        print(error.localizedDescription)
    }
    return nil
}




func myAsyncFuncA() async -> String {
    print("A start")
    try? await Task.sleep(for: .seconds(6))
    return "A"
}
 
func myAsyncFuncB() async -> String {
    print("B start")
    try? await Task.sleep(for: .seconds(3))
    return "B"
}

func callMethods() {
    Task {
        async let resultA = myAsyncFuncA()
        async let resultB = myAsyncFuncB()
        print("Both have been triggered")
        await print(resultA, resultB)
    }
}

callMethods()


protocol Behaviour {
    func sound()
    func eat()
    func drink()
}

protocol FlyBehaviour {
    func fly()
}

class Animal: Behaviour {
    func eat() {
        
    }
    
    func drink() {
        
    }
    
    func sound() {
        print("Animal sound")
    }
}

class Bird: Behaviour, FlyBehaviour {
    func sound() {
        
    }
    
    func eat() {
        
    }
    
    func fly() {
        
    }
    
    func drink() {
        
    }
}

class Human: Animal {
    override func sound() {
        print("human")
    }
}

class Dog: Animal {
    override func sound() {
        print("Dog")
    }
}

func fetchBehaviour(behaviour: Behaviour) { // abstract , concrete -- dependency inversion
    behaviour.sound()
}


func fetchBehaviour(behaviour: Animal) { // Liskov's substitution principle
    behaviour.sound()
}

fetchBehaviour(behaviour: Human())


func getCharCount(from array: [Character]) -> [Character:Int] {
    var dict = [Character: Int]()
    
    for char in array {
        dict[char,default: 0] += 1
    }
    
    for key in dict.keys {
        print("count for key:\(key) is \(dict[key] ?? 0)")
    }
    return dict
}

getCharCount(from: [Character("a"),Character("b"),Character("a"),Character("b"),Character("c"),Character("c"),Character("c"),Character("a"),Character("b"),Character("d"),Character("e")])

// master
// develop
// feature/featureA
// A -> featureA


let serialQueue = DispatchQueue(label: "com.example.serialQueue")

serialQueue.async {
    print("Task 1 started")
    Thread.sleep(forTimeInterval: 2) // Simulate a 2-second task
    print("Task 1 completed")
}

serialQueue.async {
    print("Task 2 started")
    Thread.sleep(forTimeInterval: 1) // Simulate a 1-second task
    print("Task 2 completed")
}

serialQueue.async {
    print("Task 3 started")
    Thread.sleep(forTimeInterval: 3) // Simulate a 3-second task
    print("Task 3 completed")
}



func useStride(in array: [Int]) {
    var ar = array
    for i in stride(from: 0, through: ar.count, by: 5) {
        let batch = Array(ar.prefix(5))
        print(batch)
        ar = Array(ar.dropFirst(5))
    }
}

useStride(in: [1,2,3,4,5,6,7,8,9,10,11])
*/

let formatter = DateFormatter()
formatter.dateStyle = .medium
formatter.timeStyle = .medium
formatter.timeZone = TimeZone(abbreviation: "UTC")
formatter.dateFormat = "MMM dd, yyyy 'at' HH:mm:ss a"
let date = formatter.string(from: Date())
print(date)





