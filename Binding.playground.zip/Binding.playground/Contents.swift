import UIKit
import Combine

/*var greeting = "Hello, playground"


class Observer<T> {
    
    var value: T? {
        didSet {
            listener?(value)
        }
    }
    
    private var listener: ((T?) ->Void)?
    
    
    init(_ value: T? = nil) {
        self.value = value
    }
    
    func bind(_ listener: @escaping ((T?) -> Void)) {
        listener(value)
        self.listener = listener
    }
}

class ViewModel {
    
    var isLoading: Observer<Bool> = Observer(false)
    
    var result: Observer<String> = Observer("")
    
    func fetchData() async throws {
        
        if self.isLoading.value ?? true {
            return
        }
        
        try await Task.sleep(nanoseconds: 100)
        self.isLoading = Observer(true)
        self.result = Observer("Response recived")
    }
}

class MyView {
    
    let viewModel = ViewModel()
    
    func renderUi() {
        viewModel.isLoading.bind { value in
            print(value!)
        }
        
        viewModel.result.bind { response in
            print(response!)
        }
        
        Task {
            try? await viewModel.fetchData()
        }
    }
}

let view = MyView()
view.renderUi()
print("running")


class NetworkService {
    
    var retryValue = 3
    var anyCancellable = Set<AnyCancellable>()
    
    func fetchResponse(url: URL, retryCount: Int) async throws ->  String {
        guard retryCount > 0 else {
            throw NSError(domain: "123", code: 123)
        }
        do {
            let (data, response) = try await URLSession.shared.data(from: url)
            return String(data: data, encoding: .utf8) ?? ""
        } catch {
            retryValue -= 1
            return try await self.fetchResponse(url: url, retryCount: retryValue)
        }
    }
    
    func fetchCombineRespose(with url: URL) async throws -> AnyCancellable {
        return URLSession.shared.dataTaskPublisher(for: url)
            .tryMap({ data,response in
                return data
            })
            .retry(3)
            .decode(type: [String].self, decoder: JSONDecoder())
            .tryMap { value in
                return value
            }
            .sink { completion in
                switch completion {
                case .finished:
                    break
                case .failure(let error):
                    print(error.localizedDescription)
                }
            } receiveValue: { response in
                print(response)
            }
    }
}



let array = [1,2,3,4,5,6].publisher

array.sink { value in
    print(value)
}

print("#########")

array.sink { completion in
    switch completion {
    case .finished:
        print("finished")
    case .failure(let error):
        print(error)
    }
} receiveValue: { value in
    print(value)
}
 */


let subject = PassthroughSubject<String, Never>()

let anyCancellable = subject.sink { completion in
    switch completion {
    case .finished:
        print("finished")
    case .failure(let error):
        print(error)
    }
} receiveValue: { value in
    print(value)
}

subject.send("vinod")
subject.send("naresh")
subject.send("Praveen")
subject.send("Sreekanth")

subject.send(completion: .finished)
anyCancellable.cancel()












